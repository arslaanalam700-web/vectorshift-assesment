import { Handle, Position } from "reactflow";

export const BaseNode = ({
  title,
  handles = [],
  children,
  style = {},
}) => {
  return (
    <div className="custom-node" style={style}>

      <div className="node-header">
        <strong className="node-title">
          {title}
        </strong>
      </div>

      <div className="node-content">
        {children}
      </div>

      {handles.map((handle) => (
        <Handle
          key={handle.id}
          type={handle.type}
          position={
            handle.position === "left"
              ? Position.Left
              : handle.position === "top"
              ? Position.Top
              : handle.position === "bottom"
              ? Position.Bottom
              : Position.Right
          }
          id={handle.id}
          style={handle.style}
        />
      ))}

    </div>
  );
};