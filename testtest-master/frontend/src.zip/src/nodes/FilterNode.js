import { BaseNode } from "../components/BaseNode";

export const FilterNode = ({ id }) => {
    return (
        <BaseNode
            title="Filter"
            handles={[
                {
                    id: `${id}-input`,
                    type: "target",
                    position: "left",
                },
                {
                    id: `${id}-output`,
                    type: "source",
                    position: "right",
                },
            ]}
        >
            <label>
                Condition:
                <input
                    type="text"
                    placeholder="value > 10"
                />
            </label>    
            </BaseNode>
    );
};