import { BaseNode } from "../components/BaseNode";

export const MathNode = ({ id }) => {
    return (
        <BaseNode
            title="Math"
            handles={[
                {
                    id: `${id}-input`,
                    type: "target",
                    position: "left",
                },
                {
                    id: `${id}-output`,
                    type: "source",
                    position: "right",
                },
            ]}
        >
            <label>
                Operation:
                <select>
                    <option value="+">+</option>
                    <option value="-">-</option>
                    <option value="*">*</option>
                    <option value="/">/</option>
                </select>
            </label>
        </BaseNode>
    );
};