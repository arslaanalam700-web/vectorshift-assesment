// textNode.js

import { BaseNode } from '../components/BaseNode';
import { useState, useRef, useEffect } from 'react';

export const TextNode = ({ id, data }) => {
  const [currText, setCurrText] = useState(data?.text || '{{input}}');
  const textareaRef = useRef(null);

  useEffect(() => {
    if (!textareaRef.current) return;

    textareaRef.current.style.height = "auto";
    textareaRef.current.style.height =
      textareaRef.current.scrollHeight + "px";
  }, [currText]);
  const longestLine = Math.max(...currText.split('\n').map(l => l.length), 1);
  const nodeWidth = Math.min(400, Math.max(200, longestLine * 8));
  const variables = [...currText.matchAll(/\{\{\s*([A-Za-z_$][A-Za-z0-9_$]*)\s*\}\}/g)]
    .map(m => m[1])
    .filter((v, i, arr) => arr.indexOf(v) === i);
 const varHandles = variables.map((v, i) => ({
  id: `${id}-${v}`,
  type: "target",
  position: "left",
  style: {
    top: `${((i + 1) / (variables.length + 1)) * 100}%`,
  },
}));

  const handleTextChange = (e) => {
    setCurrText(e.target.value);
  };

  return (
    <BaseNode
      title="Text"
      style={{
        width: `${nodeWidth}px`,
        minHeight: `${Math.max(120, variables.length * 30 + 70)}px`,
      }}
      handles={[
        ...varHandles,
        {
          id: `${id}-output`,
          type: "source",
          position: "right",
        },
      ]}
    >
      <div
        style={{
          position: "relative",
          marginBottom: "10px",
        }}
      >
        {variables.map((v, i) => (
          <div
            key={v}
            style={{
              position: "absolute",
              left: "-5px",
              top: `${((i + 1) / (variables.length + 1)) * 60}px`,
              fontSize: "11px",
            }}
          >
            {v}
          </div>
        ))}
      </div>
      <label>
        Text:
        <textarea
          ref={textareaRef}
          rows={1}
          style={{ overflow: 'hidden', resize: 'none', width: '100%' }}
          value={currText}
          onChange={handleTextChange}
        />
      </label>
    </BaseNode>
  );
}
