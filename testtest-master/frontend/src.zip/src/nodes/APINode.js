import { BaseNode } from "../components/BaseNode";

export const APINode = ({ id }) => {

    return (
        <BaseNode
            title="API"
            handles={[
                {
                    id: `${id}-request`,
                    type: "target",
                    position: "left",
                },
                {
                    id: `${id}-response`,
                    type: "source",
                    position: "right",
                },
            ]}
        >
            <label>
                URL:
                <input type="text" placeholder="https://api.example.com" />
            </label>
        </BaseNode>
    );
}