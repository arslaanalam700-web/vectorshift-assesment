import { BaseNode } from "../components/BaseNode";

export const MergeNode = ({ id }) => {
  return (
    <BaseNode
      title="Merge"
      handles={[
        {
          id: `${id}-input-a`,
          type: "target",
          position: "left",
          style: { top: "30%" },
        },
        {
          id: `${id}-input-b`,
          type: "target",
          position: "left",
          style: { top: "70%" },
        },
        {
          id: `${id}-output`,
          type: "source",
          position: "right",
        },
      ]}
    >
      <span>
        Combines two inputs
      </span>
    </BaseNode>
  );
};