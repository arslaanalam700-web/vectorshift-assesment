import { BaseNode } from "../components/BaseNode";

export const DelayNode = ({ id }) => {
  return (
    <BaseNode
      title="Delay"
      handles={[
        {
          id: `${id}-input`,
          type: "target",
          position: "left",
        },
        {
          id: `${id}-output`,
          type: "source",
          position: "right",
        },
      ]}
    >
      <label>
        Delay (ms):
        <input
          type="number"
          placeholder="1000"
        />
      </label>
    </BaseNode>
  );
};