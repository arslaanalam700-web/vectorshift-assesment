// llmNode.js

import { BaseNode } from '../components/BaseNode';

export const LLMNode = ({ id }) => {

    return (
   <BaseNode
    title="LLM"
  handles={[
    {
      id: `${id}-system`,
      type: "target",
      position: "left",
      style: { top: `${100 / 3}%` },
    },
    {
      id: `${id}-prompt`,
      type: "target",
      position: "left",
      style: { top: `${200 / 3}%` },
    },
    {
      id: `${id}-response`,
      type: "source",
      position: "right",
    },
  ]}
>
  <span>This is a LLM.</span>
   </BaseNode>
  );
}
